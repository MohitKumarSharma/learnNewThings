package game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import game.common.Coordinate;
import game.common.TargetLocations;
import game.player.Player;
import game.ship.BattleShip;
import game.ship.BattleShipTypeP;
import game.ship.BattleShipTypeQ;
import game.ship.BattleShips;

public class Client {
	static BattleArea battleArea;
	
	public static void main(String[] args) throws Exception  {
		File inputFile = new File("G:\\thoughtWorks\\BattleGameInput.txt");
		// Scanner sc = new Scanner(inputFile);
		BufferedReader br = new BufferedReader(new FileReader(inputFile));
		
		String battleAreaLine = br.readLine();
		battleArea = parseBattleAreaLine(battleAreaLine);
		
		int numberOfShips = Integer.parseInt(br.readLine());
		
		BattleShips battleShips1 = new BattleShips();
		BattleShips battleShip2 =  new BattleShips();
		
		for (int i = 0; i < numberOfShips; i++) {
			parseBattleShipLine(br.readLine(), battleShips1, battleShip2);
		}
		
		TargetLocations tLocations1 = parseTargetLocations(br.readLine());
		TargetLocations tLocations2 = parseTargetLocations(br.readLine());
		
		Player player1 = new Player("Player-1", battleShips1, tLocations1);
		Player player2 = new Player("Player-2", battleShip2, tLocations2, player1);
		
		player1.setOpponent(player2);
		
		player1.play();
		
	}
	
	public static BattleArea parseBattleAreaLine(String _bAreaLine) {
		String[] battleDim = _bAreaLine.split(" ");
		
		int width = Integer.parseInt(battleDim[0]);
		int height = battleDim[1].charAt(0) - 64;
		
		BattleArea battleArea = new BattleArea(width, height);
		
		return battleArea;
	}
	
	public static void parseBattleShipLine(String _bShipLine, BattleShips _ships1, BattleShips _ships2) throws Exception {
		String[] parts = _bShipLine.split(" ");
		String type = parts[0];
		
		int width = Integer.parseInt(parts[1]);
		int height = Integer.parseInt(parts[2]);
		
		Coordinate coords1 = new Coordinate(parts[3].charAt(0), parts[3].charAt(1));
		Coordinate coords2 = new Coordinate(parts[4].charAt(0), parts[4].charAt(1));
		
		BattleShip ship1, ship2;
		
		if (type.equals("P")) {
			ship1 = new BattleShipTypeP(width, height, coords1);
			ship2 = new BattleShipTypeP(width, height, coords2);
		} else if (type.equals("Q")){
			ship1 = new BattleShipTypeQ(width, height, coords1);
			ship2 = new BattleShipTypeQ(width, height, coords2);
		} else {
			throw new Exception(type + " This type of battle ship is not supported ");
		}
		
		if (!battleArea.isValidBattleShip(ship1)) {
			throw new Exception("Battle ship coords not valid " + ship1);
		}
		
		if (!battleArea.isValidBattleShip(ship2)) {
			throw new Exception("Battle ship coords not valid " + ship2);
		}
		
		
		_ships1.addBattleShip(ship1);
		_ships2.addBattleShip(ship2);
		
	}
	
	public static TargetLocations parseTargetLocations(String _tLocations) throws Exception {
		String[] locations = _tLocations.split(" ");
		
		TargetLocations targetLocations = new TargetLocations();
		Coordinate coords;
		
		for (String location: locations) {
			if (location.isEmpty()) {
				continue;
			}
			
			coords = new Coordinate(location.charAt(0), location.charAt(1));
			
			if (!battleArea.isValidCords(coords)) {
				throw new Exception("Not valid coordinates " + coords);
			}
			targetLocations.addTarget(coords);
		}
		
		return targetLocations;
	}
}
