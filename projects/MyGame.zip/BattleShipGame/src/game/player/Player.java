package game.player;

import java.util.HashSet;
import java.util.Set;

import game.common.Coordinate;
import game.common.TargetLocations;
import game.ship.BattleShips;

public class Player {
	private String playerName;
	private BattleShips battleShips;
	private TargetLocations targetLocations;
	private boolean isMissileFinished;
	
	// If more than one opponent we can use observer pattern.
	private Player opponent;
	
	public Player(String _playerName, BattleShips _battleShips, TargetLocations _targetLocations) {
		this.playerName = _playerName;
		this.battleShips = _battleShips;
		this.targetLocations = _targetLocations;
		
	}
	
	public Player(String _playerName, BattleShips _battleShips, TargetLocations _targetLocations, Player _opponent) {
		this(_playerName, _battleShips, _targetLocations);
		
		this.opponent = _opponent;
	}
	
	public void setOpponent(Player _opponent) {
		this.opponent = _opponent;
	}
	
	public void play() {
		/**
		 * Pass the turn to the opponent as no missile is left.
		 */
		if (this.isMissileFinished) {
			System.out.println(this.playerName + " has no more missiles left to launch");
			
			this.opponent.attacked(null, this.playerName);
			return;
		}
		
		Coordinate coords;
		
		while (true) {
			coords = this.targetLocations.removeTargets();
			
			if (coords == null) {
				this.isMissileFinished = true;
				
				System.out.println(this.playerName + " has no more missiles left to launch");
				
				if (this.opponent.isMissileFinished) {
					this.declareResult();
					
					return;
				}
			}
			
			boolean isHit = this.opponent.attacked(coords, this.playerName);
			
			if (!isHit) {
				break;
			}
		}
		
	}

	private boolean attacked(Coordinate coords, String _playerName) {
		
		if (coords != null) {
			boolean isHit = this.battleShips.isHit(coords);
			
			if (isHit) {
				System.out.println(_playerName + " fires a missile with target " + coords + " which got hit");
				
				return  true;
			}
			
			System.out.println(_playerName + " fires a missile with target " + coords + " which got miss");
		}
			
		this.play();
		
		return false;
	}
	
	public void declareResult() {
		if (this.battleShips.isDestroyed()) {
			System.out.println(this.opponent.playerName + " " + " won the match");
		} else if (this.opponent.battleShips.isDestroyed()) {
			System.out.println(this.playerName + " " + " won the match");
		} else {
			System.out.println("Match has been drawn the match");
		}
		
		System.out.println("Match ends here");
	}
	
}
