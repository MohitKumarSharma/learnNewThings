package game.ship;

import game.common.Coordinate;

public class BattleShipTypeQ extends BattleShip{
	public BattleShipTypeQ(int _width, int _height, Coordinate _coords) {
		super(_width, _height, _coords);
		
		this.initCells();
	}
	
	public void initCells() {
		for (int i = 0; i < this.getWidth(); i++) {
			for (int j = 0; j < this.getHeight(); j++) {
				this.cells[i][j] = 2;
			}
		}
	}
	
}
