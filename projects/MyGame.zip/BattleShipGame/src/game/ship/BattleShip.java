package game.ship;

import java.util.Arrays;

import game.common.Coordinate;

public abstract class BattleShip {
	private int width;
	private int height;
	private Coordinate coords;
	
	protected int [][]cells;
	
	public BattleShip(int _width, int _height, Coordinate _coords) {
		this.width = _width;
		this.height = _height;
		this.coords = _coords;
		
		cells = new int[this.width][this.height];
	}

	public abstract void initCells();
	
	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public Coordinate getCoords() {
		return this.coords;
	}
	
	public int getX() {
		return this.coords.getX();
	}

	public int getY() {
		return this.coords.getY();
	}
	
	public boolean isDestroyed() {
		boolean isDetroyed = true;
		
		for (int i = 0; i < this.getWidth(); i++) {
			for (int j = 0; j < this.getHeight(); j++) {
				if (this.cells[i][j] > 0) {
					isDetroyed = false;
					break;
				}
			}
		}
		
		return isDetroyed;
	}
	
	public boolean isHit(Coordinate _cords) {
		int tempX = _cords.getX();
		int tempY = _cords.getY();
		
		tempX = tempX - this.coords.getX();
		tempY = tempY - this.coords.getY();
		
		if ( 0 > tempX || tempX >= this.width) {
			return false;
		}
		
		if ( 0 > tempY|| tempY >= this.height) {
			return false;
		}
		
		if (cells[tempX][tempY] <= 0) {
			// Cell is already destroyed.
			return false;
		}
		
		cells[tempX][tempY] -= 1; // reducing the value after hit
		
		return true;
		
	}

	@Override
	public String toString() {
		return "BattleShip [width=" + width + ", height=" + height + ", coords=" + coords + ", cells="
				+ Arrays.toString(cells) + "]";
	}
	
	
	
}
