package game.common;

public class Coordinate {
	private int x;
	private int y;
	
	
	public Coordinate(int _x, int _y) {
		this.x = _x;
		this.y = _y;
	}
	
	public Coordinate(char _x, char _y) {
		this.x = (int)(_x - 64);
		this.y = (int)(_y - 48);
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public char getYInChar() {
		return (char)(y + 64);
	}

	@Override
	public String toString() {
		return String.valueOf((char)(x + 64)) + String.valueOf(y);
				//"Coordinate [_x=" + x + ", _y=" + y + "]";
	}
	
	
	
}
