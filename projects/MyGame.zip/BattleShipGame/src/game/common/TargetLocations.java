package game.common;

import java.util.LinkedList;
import java.util.Queue;

public class TargetLocations {
	Queue<Coordinate> targets;
	
	public TargetLocations() {
		this.targets = new LinkedList<Coordinate>();
	}
	
	public void addTarget(Coordinate _coords) {
		this.targets.add(_coords);
	}
	
	public Coordinate removeTargets() {
		return this.targets.poll();
	}

	@Override
	public String toString() {
		return "TargetLocations [targets=" + targets + "]";
	}
	
	
}
